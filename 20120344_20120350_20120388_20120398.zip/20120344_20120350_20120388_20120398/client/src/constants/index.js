export const STATUS = {
    PENDING: 'pending',
    REJECTED: 'rejected',
    ACCEPTED: 'accepted'
}

export const ROUND_TYPE = {
    TABLE: "Vòng tròn",
    ELIMINATION: "Loại trực tiếp",
}