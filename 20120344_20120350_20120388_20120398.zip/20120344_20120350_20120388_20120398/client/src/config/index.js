export const config = {
    GOOG_API_KEY:
        "126531190563-8088elu0a94jtq7d7h12iq5uurrb0tkv.apps.googleusercontent.com",
    FB_APP_ID: "563112971461449",
    API_BASE_URL: "http://localhost:5000",
    ANONYMOUS_TOKEN:
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjp7Il9pZCI6IjYxZTJkZjA4MGRmYjZiMzk2NDY5NzE2NSJ9LCJpYXQiOjE2NDIyNTgxODQsImV4cCI6MTY0Mjg2Mjk4NCwiaXNzIjoic2VydmVyYXQxMjMifQ.7sfxRfbLUrMzFaATZOtD8DI9gkoKdsBkT9HpY_nIZcg",
};
