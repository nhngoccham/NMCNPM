
export const STATUS = {
    PENDING: 'pending',
    REJECTED: 'rejected',
    ACCEPTED: 'accepted'
}