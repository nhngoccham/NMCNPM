import React from 'react'

export default function MatchDetail() {
    return (
        <div>
            
        </div>
    )
}
