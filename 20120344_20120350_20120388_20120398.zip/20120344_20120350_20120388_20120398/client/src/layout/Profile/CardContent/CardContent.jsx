import { Box } from '@chakra-ui/react'

export const CardContent = (props) => <Box {...props} />