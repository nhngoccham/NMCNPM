module.exports = {
    plugins: ["@chakra-ui/gatsby-plugin"],
};
